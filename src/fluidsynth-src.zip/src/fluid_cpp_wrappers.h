#pragma once

#ifdef __cplusplus
typedef class std_mutex_private         std_mutex;
typedef class std_recmutex_private*     std_recmutex;
typedef class std_cond_private          std_cond;
typedef class std_static_private*       std_private;
typedef class std_thread_private        std_thread;
#else
typedef struct std_mutex_private        std_mutex;
typedef struct std_recmutex_private*    std_recmutex;
typedef struct std_cond_private         std_cond;
typedef struct std_static_private*      std_private;
typedef struct std_thread_private       std_thread;
#endif

#ifdef __cplusplus
extern "C" {
#endif

std_mutex* std_mutex_create();
void std_mutex_init(std_mutex** mutex);
void std_mutex_destroy(std_mutex** mutex);
void std_mutex_lock(std_mutex* mutex);
void std_mutex_unlock(std_mutex* mutex);

void std_recmutex_init(std_recmutex* mutex);
void std_recmutex_destroy(std_recmutex* mutex);
void std_recmutex_lock(std_recmutex* mutex);
void std_recmutex_unlock(std_recmutex* mutex);

std_cond* std_cond_create();
void std_cond_destroy(std_cond** cond);
void std_cond_signal(std_cond* cond);
void std_cond_broadcast(std_cond* cond);
void std_cond_wait(std_cond* cond, std_mutex* mutex);

int   std_atomic_inc(volatile int* pValue);
int   std_atomic_dec(volatile int* pValue);
int   std_atomic_add(volatile int* pValue, const int amount);
void* std_atomic_compare_exchange_pointer(void* volatile* pDest, void* pExchange, void* pCompare);
void* std_atomic_exchange_pointer(void** ppDest, void* pExchange);
int   std_atomic_exchange(volatile int* pDest, int exchange);
int   std_atomic_compare_exchange(volatile int* pDest, int compare, int exchange);
int   std_atomic_get(volatile int* pValue);
void  std_atomic_set(volatile int* pValue, int newValue);
void* std_atomic_pointer_get(volatile void* atomic);
void  std_atomic_pointer_set(volatile void* atomic, void* value);

void  std_private_init(std_private* _private);
void  std_private_destroy(std_private* _private);
void* std_private_get(std_private* _private);
void  std_private_set(std_private* _private, void* _data);

typedef void* (*std_thread_func) (void* data);
std_thread* std_thread_create(std_thread_func func, void* data, int joinable);
void std_thread_destroy(std_thread** thread);
int std_thread_join(std_thread* thread);

short std_swap_le_16(short val);
short std_swap_be_16(short val);
unsigned short std_swap_le_u16(unsigned short val);
unsigned short std_swap_be_u16(unsigned short val);

int std_swap_le_32(int val);
int std_swap_be_32(int val);
unsigned int std_swap_le_u32(unsigned int val);
unsigned int std_swap_be_u32(unsigned int val);

#ifdef __cplusplus
}
#endif
