#pragma once

#ifdef __cplusplus
extern "C" {
#endif

FLUIDSYNTH_API int fluid_kex_get_pcm(void** pcmout);
#ifdef __cplusplus
}
#endif
