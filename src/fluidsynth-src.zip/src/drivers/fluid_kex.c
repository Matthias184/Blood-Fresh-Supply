/* FluidSynth - A Software Synthesizer
 *
 * Copyright (C) 2003  Peter Hanappe and others.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public License
 * as published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 * 02111-1307, USA
 */

#include "utils/fluidsynth_priv.h"
#include "synth/fluid_synth.h"
#include "utils/fluid_sys.h"
#include "drivers/fluid_adriver.h"
#include "utils/fluid_settings.h"
#include "drivers/fluid_cpp_kexdrv.h"

typedef struct
{
    fluid_audio_driver_t driver;
    fluid_synth_t* synth;
    fluid_audio_callback_t write;
    double sample_rate;
    fluid_bool_t shutdown;
    unsigned int buffer_byte_size;
    unsigned int queue_byte_size;
    unsigned int frame_size;
    int periods;
    int period_size;
} fluid_kex_audio_driver_t;

static fluid_kex_audio_driver_t* drv;

int fluid_kex_get_pcm(void** pcmout)
{
    drv->write(drv->synth, drv->period_size, *pcmout, 0, 2, *pcmout, 1, 2);
    return 1;
}

void fluid_kex_audio_driver_settings(fluid_settings_t* settings)
{
}

fluid_audio_driver_t* new_fluid_kex_audio_driver(fluid_settings_t* settings, fluid_synth_t* synth)
{
    drv = FLUID_NEW(fluid_kex_audio_driver_t);
    if (drv == NULL)
    {
        FLUID_LOG(FLUID_ERR, "Out of memory");
        return NULL;
    }

    FLUID_MEMSET(drv, 0, sizeof(fluid_kex_audio_driver_t));

    fluid_settings_getnum(settings, "synth.sample-rate", &drv->sample_rate);
    fluid_settings_getint(settings, "audio.periods", &drv->periods);
    fluid_settings_getint(settings, "audio.period-size", &drv->period_size);

    drv->synth = synth;
    drv->shutdown = FALSE;
    drv->frame_size = 2 * sizeof(short);
    drv->buffer_byte_size = drv->period_size * drv->frame_size;
    drv->queue_byte_size = drv->periods * drv->buffer_byte_size;

    drv->write = fluid_synth_write_s16;
    return (fluid_audio_driver_t*)drv;
}

int delete_fluid_kex_audio_driver(fluid_audio_driver_t* data)
{
    fluid_kex_audio_driver_t* drv = (fluid_kex_audio_driver_t*)data;
    drv->shutdown = TRUE;
    return 0;
}
