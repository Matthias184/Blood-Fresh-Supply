#include <mutex>
#include <condition_variable>
#include <atomic>
#include <type_traits>

#include "fluid_cpp_wrappers.h"

// ---------------------------------------------------------------------------------
//
class std_mutex_private
{
public:
    std::mutex mutex;
};

std_mutex* std_mutex_create()
{
    return new std_mutex_private();
}

void std_mutex_init(std_mutex** mutex)
{
    *mutex = new std_mutex_private();
}

void std_mutex_destroy(std_mutex** mutex)
{
    delete *mutex;
    *mutex = nullptr;
}

void std_mutex_lock(std_mutex* mutex)
{
    mutex->mutex.lock();
}

void std_mutex_unlock(std_mutex* mutex)
{
    mutex->mutex.unlock();
}

// ---------------------------------------------------------------------------------
//
class std_recmutex_private
{
public:
    std::recursive_mutex mutex;
};

void std_recmutex_init(std_recmutex* mutex)
{
    *mutex = new std_recmutex_private();
}

void std_recmutex_destroy(std_recmutex* mutex)
{
    delete *mutex;
    *mutex = nullptr;
}

void std_recmutex_lock(std_recmutex* mutex)
{
    (*mutex)->mutex.lock();
}

void std_recmutex_unlock(std_recmutex* mutex)
{
    (*mutex)->mutex.unlock();
}

// ---------------------------------------------------------------------------------
//
class std_cond_private
{
public:
    std::condition_variable cond;
};

std_cond* std_cond_create()
{
    return new std_cond_private();
}

void std_cond_destroy(std_cond** cond)
{
    delete *cond;
    *cond = nullptr;
}

void std_cond_signal(std_cond* cond)
{
    cond->cond.notify_one();
}

void std_cond_broadcast(std_cond* cond)
{
    cond->cond.notify_all();
}

void std_cond_wait(std_cond* cond, std_mutex* mutex)
{
    std::unique_lock<std::mutex> lg(mutex->mutex, std::adopt_lock_t());
    cond->cond.wait(lg);
    lg.release();
}

#if defined(_MSC_VER) || defined(__MSVCRT_VERSION__)
#define HAS_WINDOWS
#include <Windows.h>
#elif defined(linux) || defined(__linux__)
#define HAS_LINUX
#elif defined(__APPLE__)
#define HAS_MACOSX
#endif

// ---------------------------------------------------------------------------------
//
int std_atomic_inc(volatile int* pValue)
{
#ifdef HAS_WINDOWS
    return (int)InterlockedIncrement((long*)pValue);
#else
    #error Atomic operations needs support for this platform
#endif
}

int std_atomic_dec(volatile int* pValue)
{
#ifdef HAS_WINDOWS
    return (int)InterlockedDecrement((long*)pValue);
#else
    #error Atomic operations needs support for this platform
#endif
}

int std_atomic_add(volatile int* pValue, const int amount)
{
#ifdef HAS_WINDOWS
    return (int)InterlockedExchangeAdd((long*)pValue, (long)amount) + amount;
#else
    #error Atomic operations needs support for this platform
#endif
}

void* std_atomic_compare_exchange_pointer(void* volatile* pDest, void* pExchange, void* pCompare)
{
#ifdef HAS_WINDOWS
    return InterlockedCompareExchangePointer(pDest, pExchange, pCompare);
#else
    #error Atomic operations needs support for this platform
#endif
}

void* std_atomic_exchange_pointer(void** ppDest, void* pExchange)
{
#ifdef HAS_WINDOWS
    return InterlockedExchangePointer(ppDest, pExchange);
#else
    #error Atomic operations needs support for this platform
#endif
}

int std_atomic_exchange(volatile int* pDest, int exchange)
{
#ifdef HAS_WINDOWS
    return (int32_t)InterlockedExchange((long*)pDest, (long)exchange);
#else
    #error Atomic operations needs support for this platform
#endif
}

int std_atomic_compare_exchange(volatile int* pDest, int compare, int exchange)
{
#ifdef HAS_WINDOWS
    return (int32_t)InterlockedCompareExchange((long*)pDest, (long)exchange, (long)compare);
#else
    #error Atomic operations needs support for this platform
#endif
}

int std_atomic_get(volatile int* pValue)
{
    int32_t value;
    do
    {
        value = *pValue;
    } while(!(std_atomic_compare_exchange(pValue, value, value) == value));

    return value;
}

void std_atomic_set(volatile int* pValue, int newValue)
{
    std_atomic_exchange(pValue, newValue);
}

void* std_atomic_pointer_get(volatile void* atomic)
{
    void* value;
    do
    {
        value = (void*)atomic;
    } while(!(std_atomic_compare_exchange_pointer((void* volatile*)&atomic, value, value) == value));

    return value;
}

void std_atomic_pointer_set(volatile void* atomic, void* value)
{
    std_atomic_exchange_pointer((void**)&atomic, value);
}

// ---------------------------------------------------------------------------------
//
class std_static_private
{
public:
    void* pData;
};

void std_private_init(std_private* _private)
{
    *_private = new std_static_private();
}

void std_private_destroy(std_private* _private)
{
    delete *_private;
    *_private = nullptr;
}

void* std_private_get(std_private* _private)
{
    return (*_private)->pData;
}

void std_private_set(std_private* _private, void* _data)
{
    (*_private)->pData = _data;
}

// ---------------------------------------------------------------------------------
//
class std_thread_private
{
public:
    std::thread thread;
    int joinable;
};

std_thread* std_thread_create(std_thread_func func, void* data, int joinable)
{
    static unsigned int dwThreadID = 0;
    std_thread* thread = new std_thread_private();
    thread->thread = std::thread(func, data);
    thread->joinable = joinable;

    return thread;
}

void std_thread_destroy(std_thread** thread)
{
    if((*thread)->joinable)
    {
        (*thread)->thread.join();
    }

    delete *thread;
}

int std_thread_join(std_thread* thread)
{
    if(thread->joinable)
    {
        thread->thread.join();
    }

    return 0;
}

// ---------------------------------------------------------------------------------
//

#define KEX_LIL_ENDIAN  1234
#define KEX_BIG_ENDIAN  4321

#ifndef KEX_BYTEORDER
    #ifdef __linux__
    #include <endian.h>
    #define KEX_BYTEORDER  __BYTE_ORDER
    #else
        #if defined(__hppa__) || \
            defined(__m68k__) || defined(mc68000) || defined(_M_M68K) || \
            (defined(__MIPS__) && defined(__MISPEB__)) || \
            defined(__ppc__) || defined(__POWERPC__) || defined(_M_PPC) || \
            defined(__sparc__)
        #define KEX_BYTEORDER   KEX_BIG_ENDIAN
        #else
            #define KEX_BYTEORDER   KEX_LIL_ENDIAN
        #endif
    #endif
#endif

namespace kexEndian
{
    inline uint16_t Swap16(const uint16_t x)
    {
        return static_cast<uint16_t>((x<<8)|(x>>8));
    }

    inline uint32_t Swap32(const uint32_t x)
    {
        return static_cast<uint32_t>(((x<<24)|((x<<8)&0x00FF0000)|((x>>8)&0x0000FF00)|(x>>24)));
    }

    inline uint64_t Swap64(const uint64_t x)
    {
        uint32_t hi, lo;
        uint64_t xx = x;

        lo = static_cast<uint32_t>(x & 0xFFFFFFFF);
        xx >>= 32;
        hi = static_cast<uint32_t>(x & 0xFFFFFFFF);
        xx = Swap32(lo);
        xx <<= 32;
        xx |= Swap32(hi);

        return xx;
    }

    inline int16_t SwapLE16(const int16_t val)
    {
#if KEX_BYTEORDER == KEX_LIL_ENDIAN
        return val;
#else
        return Swap16(val);
#endif
    }

    inline uint16_t SwapLEU16(const uint16_t val)
    {
#if KEX_BYTEORDER == KEX_LIL_ENDIAN
        return val;
#else
        return Swap16(val);
#endif
    }

    inline int16_t SwapBE16(const int16_t val)
    {
#if KEX_BYTEORDER == KEX_LIL_ENDIAN
        return Swap16(val);
#else
        return val;
#endif
    }

    inline int32_t SwapLE32(const int32_t val)
    {
#if KEX_BYTEORDER == KEX_LIL_ENDIAN
        return val;
#else
        return Swap32(val);
#endif
    }

    inline uint32_t SwapLEU32(const uint32_t val)
    {
#if KEX_BYTEORDER == KEX_LIL_ENDIAN
        return val;
#else
        return Swap32(val);
#endif
    }

    inline int32_t SwapBE32(const int32_t val)
    {
#if KEX_BYTEORDER == KEX_LIL_ENDIAN
        return Swap32(val);
#else
        return val;
#endif
    }

    inline int64_t SwapLE64(const int64_t val)
    {
#if KEX_BYTEORDER == KEX_LIL_ENDIAN
        return val;
#else
        return Swap64(val);
#endif
    }

    inline int64_t SwapBE64(const int64_t val)
    {
#if KEX_BYTEORDER == KEX_LIL_ENDIAN
        return Swap64(val);
#else
        return val;
#endif
    }
}


short std_swap_le_16(short val)
{
    return kexEndian::SwapLE16(val);
}

short std_swap_be_16(short val)
{
    return kexEndian::SwapBE16(val);
}

unsigned short std_swap_le_u16(unsigned short val)
{
    return kexEndian::SwapLEU16(val);
}

unsigned short std_swap_be_u16(unsigned short val)
{
    return (unsigned short)kexEndian::SwapBE16((short)val);
}

int std_swap_le_32(int val)
{
    return kexEndian::SwapLE32(val);
}

int std_swap_be_32(int val)
{
    return kexEndian::SwapBE32(val);
}

unsigned int std_swap_le_u32(unsigned int val)
{
    return kexEndian::SwapLEU32(val);
}

unsigned int std_swap_be_u32(unsigned int val)
{
    return (unsigned int)kexEndian::SwapBE32((int)val);
}
